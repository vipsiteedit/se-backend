<?php

namespace Box\Spout\Common\Exception;

/**
 * Class UnsupportedTypeException
 *
 * @api
 * @package Box\Spout\Common\Exception
 */
class UnsupportedTypeException extends SpoutException
{
}
