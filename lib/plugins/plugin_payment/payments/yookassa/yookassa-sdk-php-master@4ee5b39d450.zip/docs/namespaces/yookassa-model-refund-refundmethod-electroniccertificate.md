# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa\Model\Refund\RefundMethod\ElectronicCertificate

## Parent: [\YooKassa\Model\Refund\RefundMethod](../namespaces/yookassa-model-refund-refundmethod.md)

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Model\Refund\RefundMethod\ElectronicCertificate\ElectronicCertificateRefundArticle](../classes/YooKassa-Model-Refund-RefundMethod-ElectronicCertificate-ElectronicCertificateRefundArticle.md) | Класс, представляющий модель ElectronicCertificateRefundArticle. |
| [\YooKassa\Model\Refund\RefundMethod\ElectronicCertificate\ElectronicCertificateRefundData](../classes/YooKassa-Model-Refund-RefundMethod-ElectronicCertificate-ElectronicCertificateRefundData.md) | Класс, представляющий модель ElectronicCertificateRefundData. |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 0](../reports/markers.md)
* [Deprecated - 40](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2025-12-17 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2025 YooMoney