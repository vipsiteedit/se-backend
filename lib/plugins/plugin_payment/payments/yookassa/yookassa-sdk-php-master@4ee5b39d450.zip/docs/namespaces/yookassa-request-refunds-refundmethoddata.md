# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa\Request\Refunds\RefundMethodData

## Parent: [\YooKassa\Request\Refunds](../namespaces/yookassa-request-refunds.md)

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Request\Refunds\RefundMethodData\AbstractRefundMethodData](../classes/YooKassa-Request-Refunds-RefundMethodData-AbstractRefundMethodData.md) | Класс, представляющий модель AbstractRefundMethod. |
| [\YooKassa\Request\Refunds\RefundMethodData\RefundMethodDataElectronicCertificate](../classes/YooKassa-Request-Refunds-RefundMethodData-RefundMethodDataElectronicCertificate.md) | Класс, представляющий модель ElectronicCertificateRefundMethod. |
| [\YooKassa\Request\Refunds\RefundMethodData\RefundMethodDataFactory](../classes/YooKassa-Request-Refunds-RefundMethodData-RefundMethodDataFactory.md) | Класс, представляющий модель RefundMethodDataFactory. |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 0](../reports/markers.md)
* [Deprecated - 40](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2025-12-17 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2025 YooMoney